# 🔔 Special Needs World - Push Notifications Setup Guide

## Current Status

Your setup has:
- ✅ Database tables: `push_subscriptions`, `scheduled_notifications`, `notification_settings`
- ✅ Cron job: `process-notifications` (marks pending → processing)
- ✅ Edge Function deployed: `send-notifications`
- ❌ **Missing**: Cron job to CALL the Edge Function
- ❌ **Missing**: VAPID secrets on Edge Function

---

## Step 1: Generate VAPID Keys

Run this command in your terminal:

```bash
npx web-push generate-vapid-keys
```

You'll get output like:
```
=======================================

Public Key:
BCnxcwQx2e8Zn8W_fgdQRMuT7he68IEH7pAQxbocw3gsYaIRZIJyzEkuESXPFfFaqy9xT6eDhVGx0Z5QLxG2URQ

Private Key:
4Ok3EZkdQWdwJnmCv-7Vm46sxJ6OBi8xP8ccKMib1rY

=======================================
```

**Save both keys!** You'll need them in the next steps.

---

## Step 2: Add VAPID Secrets to Edge Function

Go to **Supabase Dashboard** → **Edge Functions** → **send-notifications** → **Secrets**

Add these three secrets:

| Secret Name | Value |
|-------------|-------|
| `VAPID_PUBLIC_KEY` | Your public key from Step 1 |
| `VAPID_PRIVATE_KEY` | Your private key from Step 1 |
| `VAPID_EMAIL` | `mailto:kcassel888@gmail.com` |

⚠️ **Important**: The secret names must be EXACTLY as shown (case-sensitive).

---

## Step 3: Add VAPID Public Key to Netlify

Go to **Netlify** → **Site Settings** → **Environment Variables**

Add:
| Variable Name | Value |
|---------------|-------|
| `VITE_VAPID_PUBLIC_KEY` | Your public key from Step 1 |

Then **redeploy** the site for the change to take effect.

---

## Step 4: Enable pg_net Extension

Go to **Supabase Dashboard** → **Database** → **Extensions**

Search for `pg_net` and **enable** it.

---

## Step 5: Deploy Updated Edge Function

The Edge Function has been fixed. Deploy it:

```bash
cd your-project-directory
supabase functions deploy send-notifications --no-verify-jwt
```

---

## Step 6: Add Missing Cron Job

Go to **Supabase Dashboard** → **SQL Editor**

Run the contents of `database/add-edge-function-cron.sql`

This adds:
- `send-notifications` cron job (calls Edge Function every minute)
- `cleanup-old-notifications` cron job (daily cleanup)

---

## Step 7: Copy Badge Icon to Public Folder

Copy `public/badge-icon.svg` to your project's `public/` folder.

Also, ensure you have these files in your `public/` folder:
- `logo.jpeg` (192x192 recommended) - main notification icon
- `badge-icon.png` (96x96) - status bar badge

To convert SVG to PNG (if needed):
```bash
# Using ImageMagick
convert -background none public/badge-icon.svg -resize 96x96 public/badge-icon.png

# Or use an online converter like https://svgtopng.com/
```

---

## Step 8: Verify Setup

### Check Cron Jobs:
```sql
SELECT jobid, jobname, schedule, active FROM cron.job;
```

Expected output:
| jobname | schedule | active |
|---------|----------|--------|
| process-notifications | * * * * * | t |
| send-notifications | * * * * * | t |
| cleanup-old-notifications | 0 3 * * * | t |

### Check Recent Cron Runs:
```sql
SELECT jobname, status, return_message, start_time 
FROM cron.job_run_details 
ORDER BY start_time DESC 
LIMIT 10;
```

### Test Edge Function Manually:
```bash
curl -X POST 'https://gwcfqhfxqkzztxrfwsed.supabase.co/functions/v1/send-notifications'
```

Expected response:
```json
{"message":"No notifications to send","count":0}
```

If you see an error about VAPID keys, the secrets aren't set correctly.

---

## Step 9: Test End-to-End

1. **Sign in** to Special Needs World
2. Go to **Settings** → **Notifications** → Enable notifications
3. Go to **Visual Schedule**
4. Create an activity with a time **2 minutes from now**
5. **Save** the schedule
6. Wait for the notification!

---

## How It Works (Architecture)

```
┌─────────────────────────────────────────────────────────────────┐
│                    USER CREATES SCHEDULE                         │
│         (Visual Schedule → Save with notification time)          │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                  scheduled_notifications table                   │
│              status: 'pending', scheduled_for: time              │
└─────────────────────────┬───────────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          │    pg_cron (every minute)     │
          │  process-notifications job    │
          └───────────────┬───────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│              Marks due notifications as 'processing'             │
└─────────────────────────┬───────────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          │    pg_cron (every minute)     │
          │   send-notifications job      │
          │      (calls Edge Function)    │
          └───────────────┬───────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│               Edge Function: send-notifications                  │
│    - Fetches 'processing' notifications                          │
│    - Gets user's push subscriptions                              │
│    - Sends Web Push via VAPID                                    │
│    - Marks as 'sent' or 'failed'                                 │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                   USER'S DEVICE RECEIVES                         │
│                   🔔 Push Notification                           │
│                   with themed icon & actions                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Troubleshooting

### "VAPID keys not configured" error
→ VAPID secrets not set on Edge Function. Go to Dashboard → Edge Functions → Secrets.

### Notifications not sending
1. Check cron job exists: `SELECT * FROM cron.job;`
2. Check cron is running: `SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 5;`
3. Check Edge Function logs in Dashboard

### No push subscriptions found
→ User hasn't enabled notifications in the app. Go to Settings → Notifications.

### Subscription expired (410/404 errors)
→ Normal behavior. Old subscriptions are automatically cleaned up.

---

## Notification Theming

Notifications are themed for Special Needs World:
- **Icon**: App logo (`/logo.jpeg`)
- **Badge**: Heart with puzzle piece (`/badge-icon.png`)
- **Vibration**: Gentle pattern (100ms, pause, 200ms)
- **Actions**: Simple "✓ Done" and "⏰ Later" buttons
- **Tag**: Prevents duplicate notifications

---

## Files Reference

| File | Purpose |
|------|---------|
| `supabase/functions/send-notifications/index.ts` | Edge Function (corrected) |
| `database/add-edge-function-cron.sql` | SQL for missing cron job |
| `public/badge-icon.svg` | Notification badge icon |

---

## Quick Reference Commands

```bash
# Generate VAPID keys
npx web-push generate-vapid-keys

# Deploy Edge Function
supabase functions deploy send-notifications --no-verify-jwt

# Set secrets (alternative to Dashboard)
supabase secrets set VAPID_PUBLIC_KEY=your_public_key
supabase secrets set VAPID_PRIVATE_KEY=your_private_key
supabase secrets set VAPID_EMAIL=mailto:kcassel888@gmail.com

# View Edge Function logs
supabase functions logs send-notifications
```
