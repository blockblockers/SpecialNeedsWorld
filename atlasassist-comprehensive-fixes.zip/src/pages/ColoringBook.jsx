// ColoringBook.jsx - Interactive Coloring Book
// FIXED: Back button now says "Back" instead of "Activities"
// Browse and color pre-made or AI-generated coloring pages

import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Palette,
  Eraser,
  RotateCcw,
  Save,
  Download,
  ChevronLeft,
  Loader2,
  Sparkles,
  Search,
  Grid3X3,
  Heart,
  Check
} from 'lucide-react';
import { useAuth } from '../App';
import {
  CATEGORIES,
  COLOR_PALETTE,
  getColoringPages,
  getColoringPageById,
  saveUserColoring,
  getUserColoring,
  generateColoringPage,
} from '../services/coloringBook';

// ============================================
// COLOR PICKER COMPONENT
// ============================================

const ColorPicker = ({ selectedColor, onSelectColor, onSelectEraser, isEraser }) => {
  return (
    <div className="bg-white rounded-2xl border-4 border-[#E63B2E] p-3 shadow-crayon">
      <div className="flex items-center gap-2 mb-2">
        <Palette size={20} className="text-[#E63B2E]" />
        <span className="font-crayon text-sm text-gray-600">Colors</span>
      </div>
      
      <div className="grid grid-cols-7 gap-1.5">
        {COLOR_PALETTE.map((color) => (
          <button
            key={color.hex}
            onClick={() => onSelectColor(color.hex)}
            className={`w-8 h-8 rounded-lg border-2 transition-all ${
              selectedColor === color.hex && !isEraser
                ? 'border-gray-800 scale-110 shadow-md' 
                : 'border-gray-300 hover:scale-105'
            }`}
            style={{ backgroundColor: color.hex }}
            title={color.name}
          />
        ))}
      </div>
      
      {/* Eraser */}
      <div className="mt-3 pt-3 border-t border-gray-200">
        <button
          onClick={onSelectEraser}
          className={`w-full py-2 px-3 rounded-xl flex items-center justify-center gap-2 font-crayon text-sm transition-all ${
            isEraser 
              ? 'bg-[#E63B2E] text-white' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          <Eraser size={18} />
          Eraser
        </button>
      </div>
    </div>
  );
};

// ============================================
// COLORING CANVAS COMPONENT
// ============================================

const ColoringCanvas = ({ svgContent, coloredSvg, selectedColor, isEraser, onSvgChange }) => {
  const containerRef = useRef(null);
  const [currentSvg, setCurrentSvg] = useState('');
  
  useEffect(() => {
    setCurrentSvg(coloredSvg || svgContent);
  }, [svgContent, coloredSvg]);
  
  const handleClick = useCallback((e) => {
    const target = e.target;
    
    // Only color paths and shapes, not the background
    if (target.tagName === 'path' || target.tagName === 'circle' || 
        target.tagName === 'rect' || target.tagName === 'ellipse' ||
        target.tagName === 'polygon') {
      
      const newColor = isEraser ? 'white' : selectedColor;
      
      // Check if it's a stroke-colorable element (like rainbow arcs)
      if (target.hasAttribute('data-stroke-colorable')) {
        target.setAttribute('stroke', newColor);
      } else {
        target.setAttribute('fill', newColor);
      }
      
      // Get updated SVG
      const container = containerRef.current;
      if (container) {
        const svgEl = container.querySelector('svg');
        if (svgEl) {
          const newSvgContent = svgEl.outerHTML;
          setCurrentSvg(newSvgContent);
          onSvgChange(newSvgContent);
        }
      }
    }
  }, [selectedColor, isEraser, onSvgChange]);
  
  return (
    <div 
      ref={containerRef}
      className="w-full aspect-square bg-white rounded-2xl border-4 border-gray-200 shadow-inner overflow-hidden cursor-pointer"
      onClick={handleClick}
      dangerouslySetInnerHTML={{ __html: currentSvg }}
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    />
  );
};

// ============================================
// PAGE CARD COMPONENT
// ============================================

const PageCard = ({ page, onClick }) => (
  <button
    onClick={onClick}
    className="bg-white rounded-2xl border-4 border-gray-200 p-3 
               hover:border-[#E63B2E] hover:shadow-crayon transition-all
               hover:-translate-y-1"
  >
    <div 
      className="w-full aspect-square bg-gray-50 rounded-xl overflow-hidden mb-2"
      dangerouslySetInnerHTML={{ __html: page.svg_content }}
      style={{ pointerEvents: 'none' }}
    />
    <h3 className="font-display text-sm text-gray-800 truncate">{page.title}</h3>
    <p className="font-crayon text-xs text-gray-500">{page.category}</p>
  </button>
);

// ============================================
// MAIN COLORING BOOK COMPONENT
// ============================================

const ColoringBook = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // State
  const [view, setView] = useState('browse'); // 'browse' or 'coloring'
  const [pages, setPages] = useState([]);
  const [currentPage, setCurrentPage] = useState(null);
  const [coloredSvg, setColoredSvg] = useState(null);
  const [selectedColor, setSelectedColor] = useState('#E63B2E');
  const [isEraser, setIsEraser] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [customPrompt, setCustomPrompt] = useState('');
  
  // Load pages on mount
  useEffect(() => {
    loadPages();
  }, []);
  
  const loadPages = async () => {
    setIsLoading(true);
    try {
      const loadedPages = await getColoringPages();
      setPages(loadedPages || []);
    } catch (error) {
      console.error('Error loading pages:', error);
      setPages([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Open a page for coloring
  const openPage = async (page) => {
    setCurrentPage(page);
    setView('coloring');
    setHasChanges(false);
    setColoredSvg(null);
    
    // Check for saved coloring
    if (user?.id) {
      const saved = await getUserColoring(user.id, page.id);
      if (saved?.colored_svg) {
        setColoredSvg(saved.colored_svg);
      }
    }
  };
  
  // Handle color selection
  const handleSelectColor = (color) => {
    setSelectedColor(color);
    setIsEraser(false);
  };
  
  // Handle SVG change
  const handleSvgChange = (newSvg) => {
    setColoredSvg(newSvg);
    setHasChanges(true);
  };
  
  // Save coloring
  const handleSave = async () => {
    if (!currentPage || !coloredSvg || !user?.id) return;
    
    setIsSaving(true);
    try {
      await saveUserColoring(user.id, currentPage.id, coloredSvg);
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving:', error);
    } finally {
      setIsSaving(false);
    }
  };
  
  // Reset coloring
  const handleReset = () => {
    if (currentPage) {
      setColoredSvg(currentPage.svg_content);
      setHasChanges(true);
    }
  };
  
  // Download coloring
  const handleDownload = () => {
    if (!coloredSvg && !currentPage?.svg_content) return;
    
    const svgData = coloredSvg || currentPage.svg_content;
    const blob = new Blob([svgData], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentPage?.title || 'coloring-page'}.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };
  
  // Generate custom page
  const handleGenerate = async () => {
    if (!customPrompt.trim()) return;
    
    setIsGenerating(true);
    try {
      const newPage = await generateColoringPage(customPrompt);
      if (newPage) {
        setPages(prev => [newPage, ...prev]);
        setCustomPrompt('');
        openPage(newPage);
      }
    } catch (error) {
      console.error('Error generating:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Filter pages
  const filteredPages = pages.filter(page => {
    const matchesCategory = selectedCategory === 'all' || page.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      page.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });
  
  // Render browse view
  const renderBrowseView = () => (
    <div>
      {/* Search and Category Filters */}
      <div className="mb-6 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search pages..."
            className="w-full pl-10 pr-4 py-3 border-3 border-gray-200 rounded-xl font-crayon
                     focus:border-[#E63B2E] focus:outline-none"
          />
        </div>
        
        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-xl font-crayon text-sm whitespace-nowrap transition-all
              ${selectedCategory === 'all' 
                ? 'bg-[#E63B2E] text-white' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
          >
            All
          </button>
          {CATEGORIES?.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl font-crayon text-sm whitespace-nowrap transition-all
                ${selectedCategory === cat.id 
                  ? 'bg-[#E63B2E] text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
            >
              {cat.emoji} {cat.name}
            </button>
          ))}
        </div>
        
        {/* AI Generate */}
        <div className="flex gap-2">
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="Create your own: e.g., 'a happy dinosaur'"
            className="flex-1 px-4 py-3 border-3 border-gray-200 rounded-xl font-crayon
                     focus:border-[#E63B2E] focus:outline-none"
          />
          <button
            onClick={handleGenerate}
            disabled={!customPrompt.trim() || isGenerating}
            className="px-4 py-3 bg-[#8E6BBF] text-white rounded-xl font-crayon
                     hover:bg-purple-600 disabled:opacity-50 flex items-center gap-2"
          >
            {isGenerating ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Sparkles size={16} />
            )}
            Create
          </button>
        </div>
      </div>
      
      {/* Pages Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 size={32} className="text-[#E63B2E] animate-spin" />
        </div>
      ) : filteredPages.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredPages.map((page) => (
            <PageCard 
              key={page.id} 
              page={page} 
              onClick={() => openPage(page)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="font-crayon text-gray-500">No coloring pages found.</p>
          <p className="font-crayon text-sm text-gray-400 mt-1">Try creating one!</p>
        </div>
      )}
    </div>
  );
  
  // Render coloring view
  const renderColoringView = () => (
    <div className="flex flex-col lg:flex-row gap-4">
      {/* Canvas */}
      <div className="flex-1">
        <div className="bg-gray-100 rounded-3xl p-4">
          <h2 className="font-display text-lg text-gray-800 mb-3 text-center">
            {currentPage?.title}
          </h2>
          
          <ColoringCanvas
            svgContent={currentPage?.svg_content}
            coloredSvg={coloredSvg}
            selectedColor={selectedColor}
            isEraser={isEraser}
            onSvgChange={handleSvgChange}
          />
          
          {/* Action Buttons */}
          <div className="flex justify-center gap-2 mt-4">
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-gray-200 text-gray-600 rounded-xl font-crayon text-sm flex items-center gap-1"
            >
              <RotateCcw size={16} /> Reset
            </button>
            
            <button
              onClick={handleSave}
              disabled={!hasChanges || isSaving}
              className="px-4 py-2 bg-[#5CB85C] text-white rounded-xl font-crayon text-sm flex items-center gap-1 disabled:opacity-50"
            >
              {isSaving ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Save size={16} />
              )}
              Save
            </button>
            
            <button
              onClick={handleDownload}
              className="px-4 py-2 bg-[#4A9FD4] text-white rounded-xl font-crayon text-sm flex items-center gap-1"
            >
              <Download size={16} /> Download
            </button>
          </div>
        </div>
      </div>
      
      {/* Color Picker - Side panel on desktop, bottom on mobile */}
      <div className="lg:w-64">
        <ColorPicker
          selectedColor={selectedColor}
          onSelectColor={handleSelectColor}
          onSelectEraser={() => setIsEraser(true)}
          isEraser={isEraser}
        />
        
        {/* Instructions */}
        <div className="mt-4 p-3 bg-[#FFF3E0] rounded-xl border-2 border-[#F5A623]">
          <p className="font-crayon text-sm text-[#E65100]">
            💡 Tap on any shape to fill it with the selected color!
          </p>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="min-h-screen bg-[#FFFEF5]">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#FFFEF5]/95 backdrop-blur-sm border-b-4 border-[#E63B2E]">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => {
              if (view === 'coloring') {
                setView('browse');
                setCurrentPage(null);
              } else {
                navigate('/activities');
              }
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border-4 border-[#E63B2E] 
                       rounded-xl font-display font-bold text-[#E63B2E] hover:bg-[#E63B2E] 
                       hover:text-white transition-all shadow-md"
          >
            <ChevronLeft size={16} />
            {/* FIXED: Always says "Back" now */}
            Back
          </button>
          <img 
            src="/logo.jpeg" 
            alt="ATLASassist" 
            className="w-10 h-10 rounded-lg shadow-sm"
          />
          <h1 className="text-xl sm:text-2xl font-display text-[#E63B2E] crayon-text flex items-center gap-2">
            🎨 Coloring Book
          </h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {view === 'browse' && renderBrowseView()}
        {view === 'coloring' && currentPage && renderColoringView()}
      </main>
      
      {/* Generating Overlay */}
      {isGenerating && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-2xl p-8 text-center max-w-sm mx-4">
            <div className="w-16 h-16 bg-[#E63B2E]/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 size={32} className="text-[#E63B2E] animate-spin" />
            </div>
            <h3 className="font-display text-xl text-[#E63B2E] mb-2">Creating Your Page</h3>
            <p className="font-crayon text-gray-600">
              Drawing something special just for you...
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ColoringBook;
